/*
 * jwool003_lab4_part1.c
 *
 * Created: 10/18/2018 4:03:32 PM
 * Author : Jonathan
 */ 

#include <avr/io.h>


int main(void)
{
    /* Replace with your application code */
    while (1) 
    {
    }
}

